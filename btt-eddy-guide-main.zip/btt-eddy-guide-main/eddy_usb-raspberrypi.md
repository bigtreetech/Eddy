[Moved to main readme here](https://github.com/krautech/btt-eddy-guide#installation-of-eddy-usb-v1-and-raspberry-pi)
